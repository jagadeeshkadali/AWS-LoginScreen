import React, { Component } from 'react';
import { Button, Form, FormGroup, Label, Input } from 'reactstrap';

const Login = (props) => {
  return (
    <Form className="Login-form-fields">
      <FormGroup>
        <legend for="examplePassword" className="Form-title">Sign in as IAM user</legend>
      </FormGroup>
      <FormGroup>
        <Label for="accountId">Account ID (12 digits) or account alias</Label>
        <Input type="text" name="accountId" id="accountId" placeholder="viptela-tme" bsSize="sm" />
      </FormGroup>
      <FormGroup>
        <Label for="userName">IAM user name</Label>
        <Input type="text" name="userName" id="userName" bsSize="sm" />
      </FormGroup>
      <FormGroup>
        <Label for="password">Password</Label>
        <Input type="password" name="password" id="password" bsSize="sm" />
      </FormGroup>
      <Button size="sm" color="primary" block>Sign in</Button>
      <FormGroup>
        <Button className="Link-button Root-link" color="link">Sign in using root user email</Button>
        <Button className="Link-button Forgot-link" color="link">Forgot password?</Button>
      </FormGroup>
    </Form>
  );
}

export default Login;