import React, { Component } from 'react';
import { Button } from 'reactstrap';
import './Login.css';

const LoginDetails = (props) => {
    return (
        <div className="LoginDetails">
            <div className="LoginDetails-block">
                <h1>Amazon EC2 Spot Instances</h1>
                <h3>Accelerate stateless and fault-tolerant production workloads up to 10X with inexpensive compute.</h3>
                <Button outline size="sm">Learn more >></Button>
            </div>
        </div>
    );
}

export default LoginDetails;