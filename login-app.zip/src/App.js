import React from 'react';
import logo from './Images/logo.png';
import './App.css';
import './Login';
import Login from './Login';
import LoginDetails from './Login-details';
import { Container, Row, Col, Button } from 'reactstrap';

function App() {
  return (
    <div className="App">
      <Container className="themed-container" fluid="sm">
        <Row>
          <Col sm="12" md={{ size: 10, offset: 1 }}>
            <header className="App-header">
              <img src={logo} className="App-logo" alt="logo" />
            </header>
          </Col>
        </Row>
        <Row>
          <Col sm="12" md={{ size: 10, offset: 1 }}>
            <Row>
              <Col sm="12" lg="5">
                <Login></Login>
              </Col>
              <Col sm="12" lg="7">
                <LoginDetails></LoginDetails>
              </Col>
            </Row>
          </Col>
        </Row>
        <Row>
          <Col sm="12" md={{ size: 10, offset: 1 }}>
            <footer className="App-footer">
              <select id="cars" name="cars">
                  <option value="volvo">English </option>
                  <option value="saab">Hindi</option>
              </select>
              <p><a href="#" className="" color="link">Terms of Use Privacy Polict</a><span> @ 1998-2020, Amazon Web Services, Inc or its affiliates.</span></p>
            </footer>
          </Col>
        </Row>
      </Container>
    </div>
  );
}

export default App;
